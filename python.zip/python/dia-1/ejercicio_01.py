nombre = input("Cual es tu nombre: ")
edad = input("Que edad tienes: ")
print(nombre + " tiene " + edad + " años.")
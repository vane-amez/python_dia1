Edad = input("Ingrese su edad: ")
if Edad >= "18":
    print("Usted es mayor de edad")
elif Edad <= "0":
    print("La edad no puede ser negativa")
else:
    print("Usted es menor de edad") 
